var a = 6;

{
    a = 2;
    var b = 3;
    var c = document;
}

2;
3;
c;