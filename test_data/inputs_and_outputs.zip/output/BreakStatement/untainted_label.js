var a = 5;

outer_loop: {
    {
        5;
        {
            {
                5;
                a--;
            }
            {
                4;
                a--;
            }
            {
                3;
            }
        }
    }
}

3;