var a = 3;
var b = document;
var c = 5;

while (b > 0) {
    a;

    {
        if (b == 6) {
            break;
        }
    }

    a -= 1;
}

a;