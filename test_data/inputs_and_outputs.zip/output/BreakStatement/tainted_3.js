var a = 3;
var b = document;

while (b > 0) {
    3;
}

3;