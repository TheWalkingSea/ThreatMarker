var a = 1;
var b;

b = a++;
2;
1;

b = ++a;
3;
3;

b = a--;
2;
3;

b = --a;
1;
1;


var c = window;
c++;