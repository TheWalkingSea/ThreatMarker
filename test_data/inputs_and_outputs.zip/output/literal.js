1;
null;
/regex/;
true;
"test";