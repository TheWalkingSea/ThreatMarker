var b = "c";
var d = 4;

var e = {
    a: 2,
    "c": 3,
    d: 4
}

2;
3;
4;