var a = 2;
2;

var b = document;
b;