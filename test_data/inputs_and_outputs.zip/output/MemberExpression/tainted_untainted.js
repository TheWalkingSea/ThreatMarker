var myList = document;
var property = document;


myList[2];