var myList = [1, 2, document, 4, 5];

document + 1;
2 + document;

2;