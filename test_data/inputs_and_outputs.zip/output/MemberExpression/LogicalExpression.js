var myList = [true, 2, document, 4, 5];

document || 1;
2 || document;

false;
true;