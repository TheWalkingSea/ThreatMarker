var myList = document;
var property = document;


myList[document];