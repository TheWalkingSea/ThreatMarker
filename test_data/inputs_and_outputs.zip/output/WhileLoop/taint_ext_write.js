var a = 2;

while (window) {
    a;
    a = a + 3;
}

a;