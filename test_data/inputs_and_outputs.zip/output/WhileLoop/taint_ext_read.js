var a = 2;

while (window) {
    var d = 4;
}