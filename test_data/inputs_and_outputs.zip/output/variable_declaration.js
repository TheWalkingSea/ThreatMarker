var a = document;

var b, c;

var d = 2;