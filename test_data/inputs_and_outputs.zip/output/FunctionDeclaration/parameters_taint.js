function foo(a) {
    var e = 2 + a;
}