function foo(a) {
    a;
}