var b;

try {
    var c = 3;
    a();
} catch {
    b = 2;
}

2;