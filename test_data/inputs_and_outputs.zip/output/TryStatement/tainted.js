var b = 2;

try {
    var a = 0;
} catch {
    b = 4;
}

b;