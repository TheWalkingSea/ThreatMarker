1;

true;

true;

false;


2;

0;

false;

true;


2;

2;

2;
