var a = 3;
var b = 4;

var c = 10;

10;