var b = 4;

var a = 2;

2;
4;