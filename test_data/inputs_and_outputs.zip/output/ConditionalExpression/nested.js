var a = 2;
var b = window;

var c = b == 4
    ? 4
    : b == 2
        ? 3
        : 50;

c;