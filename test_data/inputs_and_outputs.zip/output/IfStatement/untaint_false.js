var a = 3;
var b = 4;

3;
4;