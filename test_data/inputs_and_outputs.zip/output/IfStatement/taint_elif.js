var a = 2;
var c = document;

if (c > 0) {
    a = 4;
} else if (c < 0) {
    a = 2;
} else {
    a = 3;
}


a;


if (c > 0) {
    a = 4;
} else if (c < 0) {
    a = 2;
}


a;