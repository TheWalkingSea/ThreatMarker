function foo(a) {
    a = a + 2;
    return a;
}

foo(4),6;