function foo() {
    return 5;
}

var a = (foo(),5);
var b = 7;