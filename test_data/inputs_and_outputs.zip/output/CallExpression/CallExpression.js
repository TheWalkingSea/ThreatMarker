function foo() {
    var a = 2;
}

foo(),null;