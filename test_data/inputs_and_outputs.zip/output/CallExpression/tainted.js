function foo() {
    return window;
}

var a = foo();
var b = 2 + a;