var a = 2;
var b = document;

var c = 5;
var d = b + 2;