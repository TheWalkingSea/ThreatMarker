var a = 3;
a += 2;
5;

var b = 2;
b += 5;
7;

var c = document;
c = 7;
7;

var d = document;
d = document + 7;
d;