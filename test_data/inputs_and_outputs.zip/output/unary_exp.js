var b = 2;

b = false;
false;

"boolean";

undefined;

var c = document;
!c;