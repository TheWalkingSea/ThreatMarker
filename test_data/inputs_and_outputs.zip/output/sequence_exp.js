var b = 4;
b = (2, 4, 3);
3;

var c = (2, 3, document);
c;