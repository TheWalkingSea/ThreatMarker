var b = 2;

b = !2;
b;

typeof b;

void b;

var c = document;
!c;