var a = 3;
var b = document;

while (b > 0) {
    a;

    break;

    a -= 1;
}

a;