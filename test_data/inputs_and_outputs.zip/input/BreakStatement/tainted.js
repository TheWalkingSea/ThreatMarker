var a = 0;
while (a < 5) {
    if (document) {
        break;
    }
    a += 1;
}

a;