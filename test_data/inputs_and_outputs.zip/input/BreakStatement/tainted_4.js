var a = 3;
var b = document;
var c = 5;

while (b > 0) {
    a;

    if (a == 1) {
        c;
        break;
        c -= 2;
    }

    a -= 1;
}

a;