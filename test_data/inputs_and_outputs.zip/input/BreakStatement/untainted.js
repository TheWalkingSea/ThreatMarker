var a = 3;

while (a > 0) {
    a;

    if (a == 1) break;

    a--;
}

a;