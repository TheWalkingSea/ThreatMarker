var a = 2;
var c = document;

if (c > 0) {
    a = 4;
} else if (c < 0) {
    a = 2;
} else {
    if (4 % 2 == 0) {
        a = 3;
    }
}


a;


if (c > 0) {
    a = 4;
} else if (c < 0) {
    a = 2;
} else {
    if (4 % 2 == 1) {
        a = 3; 
    }
}


a;