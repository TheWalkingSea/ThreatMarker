var b = 4;
b = (2, b, 3);
b;

var c = (2, b, document);
c;