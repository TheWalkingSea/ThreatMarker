let b = 3;

let a = [1, 2, b];

a;