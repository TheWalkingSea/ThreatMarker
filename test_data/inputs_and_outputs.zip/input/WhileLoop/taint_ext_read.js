var a = 2;

while (window) {
    var d = a + 2;
}
