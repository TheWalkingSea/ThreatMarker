while (window) {
    var b = 3;
    b += 6;
    b;
}

b;