var a = 4;

while (a > 2) {
    a--;
}

a;