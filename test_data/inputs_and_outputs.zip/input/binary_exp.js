var a = 2;
var b = document;

var c = a + 3;
var d = b + 2;