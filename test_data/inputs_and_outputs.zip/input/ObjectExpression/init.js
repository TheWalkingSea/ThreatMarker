var b = 'c';
var d = 4;

var e = {
    a: 2,
    [b]: 3,
    d
}

e.a;
e.c;
e.d;