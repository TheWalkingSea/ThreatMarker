var b = 4;

var a = b == 10000 ? 1 : 2;

a;
b;