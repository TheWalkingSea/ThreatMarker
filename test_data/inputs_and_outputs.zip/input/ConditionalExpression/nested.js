var a = 2;
var b = window;

var c = b == 4
    ? 4
    : b == a
        ? 3
        : 2 == 3
            ? 203103
            : 50;

c;