var a = 2;
var b = window;

var c = b == 2 ? a : 6;

c;