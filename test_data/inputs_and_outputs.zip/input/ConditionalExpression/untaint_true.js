var a = 3;
var b = 4;

var c = b == 4 ? 10 : 11;

c;