var a = 1;
var b;

b = a++;
a;
b;

b = ++a;
a;
b;

b = a--;
a;
b;

b = --a;
a;
b;

var c = window;
c++;