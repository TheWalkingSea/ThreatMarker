1 || 2;

false || true;

true || false;

false || false;


1 && 2;

0 && 1;

false && true;

true && true;


null ?? 2;

2 ?? 3;

2 ?? null;
