var a = 2;
a;

var b = document;
b;