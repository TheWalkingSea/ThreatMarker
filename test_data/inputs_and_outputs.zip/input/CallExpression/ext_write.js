var a = 2;

function foo() {
    a = 4;
}

foo();

a;