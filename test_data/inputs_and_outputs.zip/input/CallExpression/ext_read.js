var a = 2;

function foo() {
    return a;
}

foo();