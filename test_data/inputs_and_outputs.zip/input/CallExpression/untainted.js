function foo() {
    return 5;
}

var a = foo();
var b = 2 + a;