var a = 3;
a += 2;
a;

var b = 2;
b += a;
b;

var c = document;
c = b;
c;

var d = document;
d = document + b;
d;