var a = 6;

{
    a = 2;
    var b = 3;
    var c = document;
}

a;
b;
c;