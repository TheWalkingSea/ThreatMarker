var b;

try {
    a();
} catch {
    b = 2;
}

b;