var b = 2;

try {
    var a = 0;
} catch {
    b = b + 2;
}

b;