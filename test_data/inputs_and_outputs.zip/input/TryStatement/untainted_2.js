var b;

try {
    var c = 3;
    a();
    c += 6;
} catch {
    b = 2;
}

b;