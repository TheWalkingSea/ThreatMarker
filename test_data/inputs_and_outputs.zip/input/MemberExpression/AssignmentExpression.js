var myList = [1, document, document, 4, 5];

myList[0] = document;
myList;

myList[0] = document;
myList;

myList[document] = 3;
myList;


myList[1] = 2;
myList;


myList[2] += 3;
myList;

myList[document] += 6;
myList;

document[2] += 2;


myList[3] += 2;
myList;